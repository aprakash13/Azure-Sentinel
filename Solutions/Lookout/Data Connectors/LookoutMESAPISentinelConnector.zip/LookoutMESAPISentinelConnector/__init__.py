import requests
import json
import datetime
import azure.functions as func
import base64
import hmac
import hashlib
import os
import logging
import re
#from .state_manager import StateManager
from .mes_request import MESRequest

customer_id = os.environ['WorkspaceID'] 
shared_key = os.environ['WorkspaceKey']
connection_string = os.environ['AzureWebJobsStorage']

log_type = 'LookoutMES'
lookout_mes_uri = "https://api.lesstage0.flexilis.org"

client_id = os.environ['ClientId']
client_secret = os.environ['ClientSecret']
access_token = os.environ.get('AccessToken')
refresh_token = os.environ.get('RefreshToken')
stream_position = os.environ.get('StreamPosition')

logAnalyticsUri = os.environ.get('logAnalyticsUri')

if ((logAnalyticsUri in (None, '') or str(logAnalyticsUri).isspace())):
    logAnalyticsUri = 'https://' + customer_id + '.ods.opinsights.azure.com'

pattern = r"https:\/\/([\w\-]+)\.ods\.opinsights\.azure.([a-zA-Z\.]+)$"
match = re.match(pattern,str(logAnalyticsUri))
if(not match):
    raise Exception("Invalid Log Analytics Uri.")


def build_signature(customer_id, shared_key, date, content_length, method, content_type, resource):
    x_headers = 'x-ms-date:' + date
    string_to_hash = method + "\n" + str(content_length) + "\n" + content_type + "\n" + x_headers + "\n" + resource
    bytes_to_hash = bytes(string_to_hash, encoding="utf-8")
    decoded_key = base64.b64decode(shared_key)
    encoded_hash = base64.b64encode(hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()).decode()
    authorization = "SharedKey {}:{}".format(customer_id,encoded_hash)
    return authorization


def post_data(body):
    method = 'POST'
    content_type = 'application/json'
    resource = '/api/logs'
    rfc1123date = datetime.datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
    content_length = len(body)
    signature = build_signature(customer_id, shared_key, rfc1123date, content_length, method, content_type, resource)
    uri = logAnalyticsUri + resource + '?api-version=2016-04-01'
    headers = {
        'content-type': content_type,
        'Authorization': signature,
        'Log-Type': log_type,
        'x-ms-date': rfc1123date
    }
    response = requests.post(uri,data=body, headers=headers)
    if (response.status_code >= 200 and response.status_code <= 299):
        return response.status_code
    else:
        logging.warn("Events are not processed into Azure. Response code: {}".format(response.status_code))
        return None


def single_ent_events(params):
    logging.info("Events fetching for client_id %s..." % str(params["client_id"]))
    mes = MESRequest(params["lookout_mes_uri"], params["client_id"], params["client_secret"], params["access_token"], params["refresh_token"], params["stream_position"])
    
    #mes.get_oauth()
    
    events = mes.get_events()
    if events and len(events) > 0:
        logging.info("Got events")        
        logging.info("Processing {} events".format(len(events)))
        #process_events(events)
        post_status_code = post_data(json.dumps(events))
        if post_status_code is not None:
            print("Posted to Sentinel")

    # for event in events:
    #     event['entName'] = params["client_id"]
    #     print(json.dumps(event) + "\r\n")


def main(mytimer: func.TimerRequest)  -> None:
    # logging.basicConfig(level=logging.INFO,
    #     format='%(asctime)s %(levelname)-8s %(threadName)s %(message)s',
    #     datefmt='%m-%d %H:%M')
    print("************Great************")
    if mytimer.past_due:
        logging.info('The timer is past due!')
    
    logging.info("Application starting")
    params = {
        "client_id" : client_id,
        "client_secret" : client_secret,
        "connection_string" : connection_string,
        "lookout_mes_uri" : lookout_mes_uri,
        "access_token" : access_token,
        "refresh_token" : refresh_token,
        "stream_position" : stream_position
    }

    single_ent_events(params)
    